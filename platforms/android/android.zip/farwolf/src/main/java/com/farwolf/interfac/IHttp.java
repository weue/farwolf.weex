package com.farwolf.interfac;





public interface IHttp {

	public void OnPostStart(Object o);
	
	public void OnPostCompelete(Object o);
	
	public void OnException(Object o);
	
}
