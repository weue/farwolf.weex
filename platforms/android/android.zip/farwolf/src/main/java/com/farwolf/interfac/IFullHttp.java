package com.farwolf.interfac;

public interface IFullHttp extends IHttp {

	public void OnPostProcess(int newProgress);
	
}
