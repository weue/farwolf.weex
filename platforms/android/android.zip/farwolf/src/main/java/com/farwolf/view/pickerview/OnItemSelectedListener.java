package com.farwolf.view.pickerview;


public interface OnItemSelectedListener {
    void onItemSelected(int index);
}
