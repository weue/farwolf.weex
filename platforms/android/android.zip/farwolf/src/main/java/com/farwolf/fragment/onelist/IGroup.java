package com.farwolf.fragment.onelist;

import java.util.List;

public interface IGroup<T> {
	public List<T> getList();
}
