package com.farwolf.view.progress;

public interface IProgress {

	
	public void show();
	public void dismiss();
	
	
	
}
