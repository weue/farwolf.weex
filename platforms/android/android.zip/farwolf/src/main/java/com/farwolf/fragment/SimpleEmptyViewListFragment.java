package com.farwolf.fragment;

import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

import com.farwolf.fragment.onelist.EmptyView;
import com.farwolf.fragment.onelist.ExceptionEmptyView;
import com.farwolf.fragment.onelist.OneListViewFragment;
import com.farwolf.view.PullToRefreshView;

 

public abstract class SimpleEmptyViewListFragment<T>  extends OneListViewFragment<T>{

	
	
	
//    @Override
//	public void onHeaderParepareRefresh(PullToRefreshView view) {
//		// TODO Auto-generated method stub
//		super.onHeaderParepareRefresh(view);
//		hideEmptyView();
//		hideExceptionView();
//	}
//    
//    @Override
//    public void onHeaderRefreshCancle(PullToRefreshView view) {
//    	// TODO Auto-generated method stub
//    	super.onHeaderRefreshCancle(view);
//    	if(isException)
//    	{
//    		showExceptionView();
//    	}
//    	if(isEmpty)
//    	{
//    		showEmptyView();
//    	}
//    	
//    }
	 
	
	

}
