package com.taobao.weex.adapter;

/**
 * Created by zhengshihan on 2017/5/23.
 */

public interface ICrashInfoReporter {
  void addCrashInfo(String key ,String value);
}
