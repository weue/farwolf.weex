package com.farwolf.weex.core;

import android.view.View;

import com.taobao.weex.WXSDKInstance;

/**
 * Created by zhengjiangrong on 2017/5/9.
 */

public class Page {


    public String id;
    public View v;
    public WXSDKInstance instance;
    public String url;


}
