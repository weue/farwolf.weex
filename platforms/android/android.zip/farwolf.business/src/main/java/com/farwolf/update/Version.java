package com.farwolf.update;

/**
 * Created by zhengjiangrong on 2017/4/12.
 */

public class Version {

    public Long id;

    public String name;

    public String versionName;

    public Integer versionCode;

    public Integer systemType;

    public String appId;


    public String desc;
    public String size;

    public String downloadUrl;

    public String source;

}
